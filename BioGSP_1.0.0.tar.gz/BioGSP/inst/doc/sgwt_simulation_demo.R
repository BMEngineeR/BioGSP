## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, warning = FALSE, message = FALSE, 
                      fig.width = 10, fig.height = 6)

## ----load-libraries-----------------------------------------------------------
# Load required packages
library(ggplot2)
library(patchwork)
library(viridis)
library(Matrix)
library(igraph)
library(RANN)
library(RSpectra)

# Load BioGSP functions
source('../R/simulation.R')
source('../R/sgwt_core.R')
source('../R/sgwt_main.R')
source('../R/utilities.R')
source('../R/visualization.R')

# Set random seed for reproducibility
set.seed(123)

## ----generate-pattern---------------------------------------------------------
# Create a spatial pattern with concentric circles
demo_pattern <- simulate_multiscale(
  grid_size = 40,        # Moderate size for fast computation
  n_centers = 1,         # Single center pattern
  Ra_seq = 5,            # Inner circle radius
  Rb_seq = 10,           # Outer ring radius
  seed = 123
)[[1]]

# Display pattern structure
cat("Generated pattern dimensions:", nrow(demo_pattern), "x", ncol(demo_pattern), "\n")
cat("Column names:", paste(colnames(demo_pattern), collapse = ", "), "\n")
cat("Signals available:", sum(demo_pattern$signal_1), "inner pixels,", sum(demo_pattern$signal_2), "outer pixels\n")

## ----visualize-pattern, fig.width=10, fig.height=4----------------------------
# Create visualizations for both signals
p1 <- ggplot(demo_pattern, aes(X, Y, fill = factor(signal_1))) +
  geom_tile() +
  scale_fill_manual(values = c("0" = "white", "1" = "#e31a1c"), 
                    name = "Signal", labels = c("Background", "Inner Circle")) +
  coord_fixed() + theme_void() + ggtitle("Signal 1: Inner Circles")

p2 <- ggplot(demo_pattern, aes(X, Y, fill = factor(signal_2))) +
  geom_tile() +
  scale_fill_manual(values = c("0" = "white", "1" = "#1f78b4"), 
                    name = "Signal", labels = c("Background", "Outer Ring")) +
  coord_fixed() + theme_void() + ggtitle("Signal 2: Outer Rings")

print(p1 + p2)

## ----init-sgwt----------------------------------------------------------------
# Initialize SGWT object with custom column names
SG <- initSGWT(
  data.in = demo_pattern,
  x_col = "X",           # Custom X coordinate column name
  y_col = "Y",           # Custom Y coordinate column name
  signals = c("signal_1", "signal_2"),  # Analyze both signals
  J = 4,                 # Number of wavelet scales
  scaling_factor = 2,    # Scale progression factor
  kernel_type = "heat"
)

# Display initialized object
print(SG)

## ----build-graph--------------------------------------------------------------
# Build spectral graph structure
SG <- runSpecGraph(SG, k = 12, laplacian_type = "normalized", length_eigenvalue = 100, verbose = TRUE)

# Check updated object
cat("Graph construction completed!\n")
cat("Adjacency matrix dimensions:", dim(SG$Graph$adjacency_matrix), "\n")
cat("Number of eigenvalues computed:", length(SG$Graph$eigenvalues), "\n")

## ----fourier-modes, fig.width=12, fig.height=8--------------------------------
# Visualize Fourier modes (eigenvectors) - 5 low and 5 high frequency modes
fourier_modes <- plot_FM(SG, mode_type = "both", n_modes = 5, ncol = 5)

cat("Fourier Modes Visualization:\n")
cat("- Low-frequency modes (2-6): Smooth spatial patterns, excluding DC component\n")
cat("- High-frequency modes (96-100): Fine-detailed spatial patterns\n")
cat("- Each mode shows its eigenvalue (λ) indicating frequency content\n")

## ----run-sgwt-----------------------------------------------------------------
# Perform SGWT forward and inverse transforms
SG <- runSGWT(SG, verbose = TRUE)

# Display final object with all results
print(SG)

## ----plot-decomposition, fig.width=12, fig.height=8---------------------------
# Plot SGWT decomposition results for signal_1
decomp_plots <- plot_sgwt_decomposition(
  SG = SG,
  signal_name = "signal_1",
  plot_scales = 1:3,     # Show first 3 scales
  ncol = 3
)


## ----energy-analysis----------------------------------------------------------
# Analyze energy distribution across scales for signal_1
energy_analysis <- sgwt_energy_analysis(SG, "signal_1")
print(energy_analysis)

# Create energy distribution plot
energy_plot <- ggplot(energy_analysis, aes(x = scale, y = energy_ratio)) +
  geom_bar(stat = "identity", fill = "steelblue", alpha = 0.7) +
  geom_text(aes(label = paste0(round(energy_ratio * 100, 1), "%")), 
            vjust = -0.5, size = 3) +
  labs(title = "Energy Distribution Across SGWT Scales (Signal 1)",
       x = "Scale", y = "Energy Ratio") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

print(energy_plot)

## ----kernel-comparison--------------------------------------------------------
# Compare different kernel types
kernels <- c("mexican_hat", "meyer", "heat")
kernel_results <- list()

for (kn in kernels) {
  # Initialize with different kernel
  SG_temp <- initSGWT(
    data.in = demo_pattern,
    x_col = "X", y_col = "Y",
    signals = "signal_1",
    J = 3,                    # Reduced for faster computation
    kernel_type = kn
  )
  
  # Run full workflow
  SG_temp <- runSpecGraph(SG_temp, k = 12, laplacian_type = "normalized", length_eigenvalue = 100,verbose = FALSE)
  SG_temp <- runSGWT(SG_temp, verbose = FALSE)
  
  kernel_results[[kn]] <- SG_temp
}

# Compare reconstruction errors
comparison_df <- data.frame(
  Kernel = kernels,
  RMSE = sapply(kernel_results, function(x) x$Inverse$signal_1$reconstruction_error),
  stringsAsFactors = FALSE
)

print("Kernel Performance Comparison:")
print(comparison_df)

# Plot comparison
ggplot(comparison_df, aes(x = Kernel, y = RMSE, fill = Kernel)) +
  geom_bar(stat = "identity", alpha = 0.7) +
  geom_text(aes(label = round(RMSE, 6)), vjust = -0.5) +
  scale_fill_viridis_d() +
  labs(title = "SGWT Reconstruction Error by Kernel Type",
       x = "Kernel Type", y = "RMSE") +
  theme_minimal()

## ----similarity-analysis------------------------------------------------------
# Calculate similarity between signal_1 and signal_2 in same object
similarity_within <- runSGCC("signal_1", "signal_2", SG = SG, return_parts = TRUE)

cat("Pattern Similarity Analysis (within same graph):\n")
cat(sprintf("Overall similarity: %.4f\n", similarity_within$S))
cat(sprintf("Low-frequency similarity: %.4f\n", similarity_within$c_low))
cat(sprintf("Non-low-frequency similarity: %.4f\n", similarity_within$c_nonlow))
cat(sprintf("Energy weights - Low: %.3f, Non-low: %.3f\n", 
           similarity_within$w_low, similarity_within$w_NL))

# Generate a second pattern for cross-comparison
pattern_2 <- simulate_multiscale(
  grid_size = 40,
  n_centers = 1,
  Ra_seq = 7,            # Different inner radius
  Rb_seq = 12,           # Different outer radius
  seed = 456
)[[1]]

# Create second SGWT object
SG2 <- initSGWT(pattern_2, x_col = "X", y_col = "Y", signals = "signal_1", 
                J = 4)
SG2 <- runSpecGraph(SG2, k = 12, laplacian_type = "normalized",length_eigenvalue = 100, verbose = FALSE)
SG2 <- runSGWT(SG2, verbose = FALSE)

# Calculate cross-object similarity
similarity_cross <- runSGCC(SG, SG2, return_parts = TRUE)

cat("\nCross-object Pattern Similarity:\n")
cat(sprintf("Overall similarity: %.4f\n", similarity_cross$S))
cat(sprintf("Low-frequency similarity: %.4f\n", similarity_cross$c_low))
cat(sprintf("Non-low-frequency similarity: %.4f\n", similarity_cross$c_nonlow))

# Visualize both patterns for comparison
p_comp1 <- ggplot(demo_pattern, aes(X, Y, fill = factor(signal_1))) +
  geom_tile() + scale_fill_manual(values = c("0" = "white", "1" = "#e31a1c")) +
  coord_fixed() + theme_void() + theme(legend.position = "none") +
  ggtitle("Pattern A (R_in=5, R_out=10)")

p_comp2 <- ggplot(pattern_2, aes(X, Y, fill = factor(signal_1))) +
  geom_tile() + scale_fill_manual(values = c("0" = "white", "1" = "#1f78b4")) +
  coord_fixed() + theme_void() + theme(legend.position = "none") +
  ggtitle("Pattern B (R_in=7, R_out=12)")

print(p_comp1 + p_comp2)

## ----low-frequency-analysis---------------------------------------------------
# Compare using only low-frequency components
similarity_low <- runSGCC("signal_1", "signal_2", SG = SG, low_only = TRUE, return_parts = TRUE)

cat("Low-frequency Only Similarity Analysis:\n")
cat(sprintf("Low-frequency similarity: %.4f\n", similarity_low$c_low))
cat(sprintf("Overall score (same as low-freq): %.4f\n", similarity_low$S))
cat("Note: Non-low-frequency components are ignored (c_nonlow = NA)\n")

# Compare with full analysis
cat("\nComparison:\n")
cat(sprintf("Full analysis similarity: %.4f\n", similarity_within$S))
cat(sprintf("Low-only similarity: %.4f\n", similarity_low$S))
cat(sprintf("Difference: %.4f\n", abs(similarity_within$S - similarity_low$S)))

## ----multiple-signals---------------------------------------------------------
# Analyze energy distribution for both signals
energy_signal1 <- sgwt_energy_analysis(SG, "signal_1")
energy_signal2 <- sgwt_energy_analysis(SG, "signal_2")

# Combine for comparison
energy_comparison <- rbind(energy_signal1, energy_signal2)

# Plot comparison
ggplot(energy_comparison, aes(x = scale, y = energy_ratio, fill = signal)) +
  geom_bar(stat = "identity", position = "dodge", alpha = 0.7) +
  geom_text(aes(label = paste0(round(energy_ratio * 100, 1), "%")), 
            position = position_dodge(width = 0.9), vjust = -0.5, size = 3) +
  scale_fill_viridis_d() +
  labs(title = "Energy Distribution Comparison: Signal 1 vs Signal 2",
       x = "Scale", y = "Energy Ratio", fill = "Signal") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

## ----custom-parameters--------------------------------------------------------
# Demonstrate advanced parameter customization
SG_advanced <- initSGWT(
  data.in = demo_pattern,
  x_col = "X", y_col = "Y",
  signals = "signal_1",
  J = 6,                     # More scales for finer analysis
  scaling_factor = 1.5,      # Closer scales
  kernel_type = "heat"       # Heat kernel
)

SG_advanced <- runSpecGraph(SG_advanced, k = 15, laplacian_type = "randomwalk",length_eigenvalue = 30, verbose = FALSE)
SG_advanced <- runSGWT(SG_advanced, verbose = FALSE)

cat("Advanced Parameters Results:\n")
cat("Number of scales:", length(SG_advanced$Parameters$scales), "\n")
cat("Scales:", paste(round(SG_advanced$Parameters$scales, 4), collapse = ", "), "\n")
cat("Reconstruction error:", round(SG_advanced$Inverse$signal_1$reconstruction_error, 6), "\n")

