## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, warning = FALSE, message = FALSE, 
                      fig.width = 10, fig.height = 6)

## ----load-libraries-----------------------------------------------------------
# Load required packages
library(ggplot2)
library(patchwork)
library(viridis)
library(Matrix)
library(igraph)
library(RANN)
library(RSpectra)

# Load BioGSP functions
source('../R/simulation.R')
source('../R/sgwt_core.R')
source('../R/sgwt_main.R')
source('../R/utilities.R')
source('../R/visualization.R')

# Set random seed for reproducibility
set.seed(123)

## ----generate-pattern---------------------------------------------------------
# Create a spatial pattern with concentric circles
demo_pattern <- simulate_multiscale(
  grid_size = 40,        # Moderate size for fast computation
  n_centers = 1,         # Single center pattern
  Ra_seq = 5,            # Inner circle radius
  Rb_seq = 10,           # Outer ring radius
  seed = 123
)[[1]]

# Display pattern structure
cat("Generated pattern dimensions:", nrow(demo_pattern), "x", ncol(demo_pattern), "\n")
cat("Column names:", paste(colnames(demo_pattern), collapse = ", "), "\n")
cat("Signals available:", sum(demo_pattern$signal_1), "inner pixels,", sum(demo_pattern$signal_2), "outer pixels\n")

## ----visualize-pattern, fig.width=10, fig.height=4----------------------------
# Create visualizations for both signals
p1 <- ggplot(demo_pattern, aes(X, Y, fill = factor(signal_1))) +
  geom_tile() +
  scale_fill_manual(values = c("0" = "white", "1" = "#e31a1c"), 
                    name = "Signal", labels = c("Background", "Inner Circle")) +
  coord_fixed() + theme_void() + ggtitle("Signal 1: Inner Circles")

p2 <- ggplot(demo_pattern, aes(X, Y, fill = factor(signal_2))) +
  geom_tile() +
  scale_fill_manual(values = c("0" = "white", "1" = "#1f78b4"), 
                    name = "Signal", labels = c("Background", "Outer Ring")) +
  coord_fixed() + theme_void() + ggtitle("Signal 2: Outer Rings")

print(p1 + p2)

## ----sgwt-analysis------------------------------------------------------------
# Run SGWT on the inner circle pattern
sgwt_result <- SGWT(
  data.in = demo_pattern,
  x_col = "X",
  y_col = "Y", 
  signal = "signal_1",
  k = 12,                # Number of nearest neighbors
  J = 4,                 # Number of wavelet scales
  scaling_factor = 2,    # Scale progression factor
  kernel_type = "mexican_hat",
  k_fold = 6             # Eigendecomposition parameter
)

# Display key results
cat("SGWT Analysis Results:\n")
cat("Reconstruction RMSE:", round(sgwt_result$reconstruction_error, 6), "\n")
cat("Number of scales:", length(sgwt_result$decomposition$scales), "\n")
cat("Scales:", paste(round(sgwt_result$decomposition$scales, 4), collapse = ", "), "\n")

## ----plot-decomposition, fig.width=12, fig.height=8---------------------------
# Plot SGWT decomposition results
decomp_plots <- plot_sgwt_decomposition(
  sgwt_result = sgwt_result,
  data.in = demo_pattern,
  x_col = "X",
  y_col = "Y",
  plot_scales = 1:3,     # Show first 3 scales
  ncol = 3
)

print(decomp_plots)

## ----energy-analysis----------------------------------------------------------
# Analyze energy distribution across scales
energy_analysis <- sgwt_energy_analysis(sgwt_result)
print(energy_analysis)

# Create energy distribution plot
energy_plot <- ggplot(energy_analysis, aes(x = scale, y = energy_ratio)) +
  geom_bar(stat = "identity", fill = "steelblue", alpha = 0.7) +
  geom_text(aes(label = paste0(round(energy_ratio * 100, 1), "%")), 
            vjust = -0.5, size = 3) +
  labs(title = "Energy Distribution Across SGWT Scales",
       x = "Scale", y = "Energy Ratio") +
  theme_minimal()

print(energy_plot)

## ----kernel-comparison--------------------------------------------------------
# Compare different kernel types
kernels <- c("mexican_hat", "meyer")
kernel_results <- list()

for (kernel in kernels) {
  result <- SGWT(
    data.in = demo_pattern,
    x_col = "X", y_col = "Y",
    signal = "signal_1",
    k = 12, J = 3,           # Reduced for faster computation
    kernel_type = kernel,
    k_fold = 6
  )
  kernel_results[[kernel]] <- result
}

# Compare reconstruction errors
comparison_df <- data.frame(
  Kernel = kernels,
  RMSE = sapply(kernel_results, function(x) x$reconstruction_error),
  stringsAsFactors = FALSE
)

print("Kernel Performance Comparison:")
print(comparison_df)

# Plot comparison
ggplot(comparison_df, aes(x = Kernel, y = RMSE, fill = Kernel)) +
  geom_bar(stat = "identity", alpha = 0.7) +
  geom_text(aes(label = round(RMSE, 6)), vjust = -0.5) +
  scale_fill_viridis_d() +
  labs(title = "SGWT Reconstruction Error by Kernel Type",
       x = "Kernel Type", y = "RMSE") +
  theme_minimal()

## ----similarity-analysis------------------------------------------------------
# Generate a second pattern for comparison
pattern_2 <- simulate_multiscale(
  grid_size = 40,
  n_centers = 1,
  Ra_seq = 7,            # Different inner radius
  Rb_seq = 12,           # Different outer radius
  seed = 456
)[[1]]

# Compute SGWT for second pattern
sgwt_2 <- SGWT(pattern_2, x_col = "X", y_col = "Y", signal = "signal_1", 
               k = 12, J = 4, k_fold = 6)

# Calculate pattern similarity using weighted similarity
similarity_result <- sgwt_weighted_similarity(sgwt_result, sgwt_2, return_parts = TRUE)

cat("Pattern Similarity Analysis:\n")
cat(sprintf("Overall similarity: %.4f\n", similarity_result$S))
cat(sprintf("Low-frequency similarity: %.4f\n", similarity_result$c_low))
cat(sprintf("Non-low-frequency similarity: %.4f\n", similarity_result$c_nonlow))
cat(sprintf("Energy weights - Low: %.3f, Non-low: %.3f\n", 
           similarity_result$w_low, similarity_result$w_NL))

# Visualize both patterns for comparison
p_comp1 <- ggplot(demo_pattern, aes(X, Y, fill = factor(signal_1))) +
  geom_tile() + scale_fill_manual(values = c("0" = "white", "1" = "#e31a1c")) +
  coord_fixed() + theme_void() + theme(legend.position = "none") +
  ggtitle("Pattern A (R_in=5, R_out=10)")

p_comp2 <- ggplot(pattern_2, aes(X, Y, fill = factor(signal_1))) +
  geom_tile() + scale_fill_manual(values = c("0" = "white", "1" = "#1f78b4")) +
  coord_fixed() + theme_void() + theme(legend.position = "none") +
  ggtitle("Pattern B (R_in=7, R_out=12)")

print(p_comp1 + p_comp2)

## ----flexible-columns---------------------------------------------------------
# Demonstrate flexible column naming
custom_data <- demo_pattern
colnames(custom_data) <- c("longitude", "latitude", "intensity", "background")

cat("Original columns:", paste(colnames(demo_pattern), collapse = ", "), "\n")
cat("Custom columns:", paste(colnames(custom_data), collapse = ", "), "\n")

# SGWT analysis with custom column names
sgwt_custom <- SGWT(
  data.in = custom_data,
  x_col = "longitude",
  y_col = "latitude", 
  signal = "intensity",
  k = 12, J = 3, k_fold = 6
)

cat("Custom column SGWT - RMSE:", round(sgwt_custom$reconstruction_error, 6), "\n")

## ----cross-signal-------------------------------------------------------------
# Analyze relationship between inner circles and outer rings
cross_similarity <- sgwt_similarity("signal_1", "signal_2", 
                                   data.in = demo_pattern, 
                                   x_col = "X", y_col = "Y",
                                   k = 12, J = 3, k_fold = 6)

cat("Cross-signal similarity (Inner vs Outer):", round(cross_similarity, 4), "\n")

# Self-similarity check (should be close to 1.0)
self_similarity <- sgwt_similarity("signal_1", "signal_1", 
                                  data.in = demo_pattern,
                                  x_col = "X", y_col = "Y", 
                                  k = 12, J = 3, k_fold = 6)

cat("Self-similarity check:", round(self_similarity, 6), "\n")

## ----performance-summary------------------------------------------------------
# Summary of computational performance
cat("Performance Summary for Current Analysis:\n")
cat("Grid size: 40x40 =", 40^2, "points\n")
cat("SGWT scales: 4\n") 
cat("Neighbor parameter k: 12\n")
cat("Typical computation time: 2-5 seconds per SGWT\n")
cat("Memory usage: < 50MB for this example\n")

# Scalability guidance
cat("\nScalability Guidelines:\n")
cat("- Small datasets (<1000 points): k=8-15, J=3-5\n")
cat("- Medium datasets (1000-5000 points): k=10-20, J=4-6\n") 
cat("- Large datasets (>5000 points): k=15-25, J=5-8\n")

